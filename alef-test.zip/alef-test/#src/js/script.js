document.addEventListener("DOMContentLoaded", function () {
  @include('_webp.js') 

  // --
  document.querySelector('#hamburger').addEventListener('click', () => {
    document.querySelector('#hamburger').classList.toggle('menu-active');
    document.querySelector('.nav').classList.toggle('nav--active');
  });

  // --

  // --
  const anchors = document.querySelectorAll('a.scroll-to');

  for (let anchor of anchors) {
    anchor.addEventListener('click', function (e) {
      e.preventDefault()
      
      const blockID = anchor.getAttribute('href')
      
      document.querySelector(blockID).scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      })
    })
  }

  window.addEventListener('scroll', function() {
    if (window.pageYOffset >= 100) {
        document.querySelector('.scroll-to').classList.add('active')
    }else{
      document.querySelector('.scroll-to').classList.remove('active')
    }
    
  });
  // --

  // --
  function notification($class, text) {
    document.querySelector(`.notification-${$class}`).innerHTML = text;
    document.querySelector(`.notification-${$class}`).classList.add('notification--active');
    setTimeout(()=>{
      document.querySelector(`.notification-${$class}`).classList.remove('notification--active');
    }, 1000)
  }

  function validateEmail(email) {
    var re = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
    return re.test(String(email).toLowerCase());
  }
  
  document.querySelector('.form-validate button').addEventListener('click', function(){
    let email = document.querySelector('.form-validate input[type="email"]').value;
    if (email !== '') {
      if (validateEmail(email)) {
        notification('correctly', "отправлено")
      }else{
        notification('error', email + " не подходит")
      } 
    }else{
      notification('error', 'заполните поле ввода')
    }
  })
  // --

  // --
  let nodeList = document.querySelectorAll('.products-block'),
      itemsArraySort = [],
      parent = nodeList[0].parentNode;

  function sort(dateid, log) {
    if (log) {
      for (var i = 0; i < nodeList.length; i++) {    
        itemsArraySort.push(parent.removeChild(nodeList[i]));
      }
      itemsArraySort.sort(function(nodeA, nodeB) {
        let textA = nodeA.querySelector(`:nth-child(2) .products-card__info-${dateid}`).getAttribute('data-sort');
        let textB = nodeB.querySelector(`:nth-child(2) .products-card__info-${dateid}`).getAttribute('data-sort');
        let numberA = parseInt(textA);
        let numberB = parseInt(textB);
        if (numberA < numberB) return -1;
        if (numberA > numberB) return 1;
        return 0;
      }).forEach(function(node){parent.appendChild(node)});
    }else{
      itemsArraySort = [];
      nodeList.forEach(function(node){
        parent.appendChild(node);
      });
    }
    document.querySelectorAll('.filter-dropdown').forEach((e)=>{
      e.classList.remove('active');
    });
  }

  document.querySelector('#filter-price').addEventListener('click', ()=>{
    if (!document.querySelector('#filter-price').classList.contains('active')) {
      sort('price', true);
      document.querySelector('#filter-price').classList.add('active');
    }else{
      sort('price', false);
    }
  });

  document.querySelector('#filter-age').addEventListener('click', ()=>{
    if (!document.querySelector('#filter-age').classList.contains('active')) {
      sort('age', true);
      document.querySelector('#filter-age').classList.add('active');
    }else{
      sort('age', false);
    }
  })
  // --
  
  // --
  let favorites = document.querySelectorAll('.heart-js');

    favorites.forEach((e)=>{
      e.addEventListener('click', function(){
        if (!e.classList.contains('active')) {
          e.classList.add('active');
          notification('correctly', "добавлено в избранное")
        }else{
          e.classList.remove('active');
          notification('correctly', "удалено из избранного")
        }
        
      })
    })
  // --



});



